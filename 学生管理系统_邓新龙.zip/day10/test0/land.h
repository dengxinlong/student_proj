#ifndef __LAND_H__
#define __LAND_H__

//�Ñ����
void usr_land(char* usr_name, char* usr_pwd);



#endif
